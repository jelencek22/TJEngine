﻿namespace Samples.FlappyBird;

public enum Direction
{
    Up, Down
}