﻿namespace Samples.FlappyBird;

enum TransitionState
{
    Nothing,
    In,
    Covering,
    Out,
}