﻿global using System;
global using System.Numerics;