﻿namespace Samples.Pong;

enum PlayerState
{
    MyServe,
    TheirServe,
    Play
}