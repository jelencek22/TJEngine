﻿namespace Samples.Pong;

enum PlayerIndex
{
    One, Two
}