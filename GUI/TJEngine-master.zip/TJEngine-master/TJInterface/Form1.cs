﻿using System;
using System.CodeDom.Compiler;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Microsoft.CSharp;
using System.Drawing;
using System.Collections.Generic;

namespace WinFormsCodeExecutor
{
    public partial class Form1 : Form
    {
        private TabControl tabControl; // Declare this as a class-level variable
        private Dictionary<TabPage, TextBox> tabTextBoxes; // Store TextBoxes for each TabPage

        public Form1()
        {
            InitializeComponent();

            // Initialize TabControl (do not declare locally)
            tabControl = new TabControl();
            tabControl.Dock = DockStyle.Fill;

            // Initialize dictionary to store TextBoxes for each tab
            tabTextBoxes = new Dictionary<TabPage, TextBox>();

            // Add the first tab
            AddNewTab(); // Use the method to add the first tab

            // Add the TabControl to the form
            this.Controls.Add(tabControl);

            // Button to add new tabs
            Button addButton = new Button
            {
                Text = "Add New Tab",
                Dock = DockStyle.Top
            };

            // Add click event for the button to dynamically add new tabs
            addButton.Click += (sender, e) =>
            {
                AddNewTab();
            };

            // Add the button to the form
            this.Controls.Add(addButton);

            // Add MouseDoubleClick event to allow renaming tabs when double-clicked
            tabControl.MouseDoubleClick += (sender, e) =>
            {
                // Check if the mouse double click is on a tab
                Point mouseLocation = e.Location;
                int tabIndex = GetTabIndexAtMouseLocation(mouseLocation);

                if (tabIndex != -1)
                {
                    // Show InputBox to rename the tab
                    RenameTab(tabIndex);
                }
            };

            // Add SelectedIndexChanged event to refresh TextBox content when switching tabs
            tabControl.SelectedIndexChanged += (sender, e) =>
            {
                // Refresh content when switching tabs
                RefreshTabContent(tabControl.SelectedTab);
            };
        }

        private void AddNewTab()
        {
            // Create a new TabPage
            TabPage newTab = new TabPage($"Tab {tabControl.TabPages.Count + 1}");

            // Create a new instance of the TextBox for each new tab
            TextBox newTextBox = new TextBox
            {
                Multiline = true,
                Dock = DockStyle.Fill
            };

            // Add the TextBox to the new tab
            newTab.Controls.Add(newTextBox);

            // Store the TextBox for the new tab
            tabTextBoxes[newTab] = newTextBox;

            // Add the new tab to the TabControl
            tabControl.TabPages.Add(newTab);
        }

        private int GetTabIndexAtMouseLocation(Point mouseLocation)
        {
            // Check each tab's header to see if the mouse double-click is within its bounds
            for (int i = 0; i < tabControl.TabPages.Count; i++)
            {
                // Get the tab's header bounds
                Rectangle tabHeaderBounds = tabControl.GetTabRect(i);

                // Check if the mouse click is within this tab's bounds
                if (tabHeaderBounds.Contains(mouseLocation))
                {
                    return i;
                }
            }
            return -1; // No tab was clicked
        }

        private void RenameTab(int tabIndex)
        {
            // Show the InputBox to rename the tab
            using (InputBox inputBox = new InputBox("Enter new tab name:"))
            {
                if (inputBox.ShowDialog() == DialogResult.OK)
                {
                    // Change the tab name to the user's input
                    tabControl.TabPages[tabIndex].Text = inputBox.UserInput;
                }
            }
        }

        // The rest of the methods for C# code execution and saving, as per your original code...

        private string ExecuteCSharpCode(string code)
        {
            using (CSharpCodeProvider codeProvider = new CSharpCodeProvider())
            {
                CompilerParameters parameters = new CompilerParameters
                {
                    GenerateInMemory = true,
                    GenerateExecutable = false
                };
                parameters.ReferencedAssemblies.Add("System.dll");

                string fullCode = @"
        using System;
        public class UserCode {
            public static string Main() {
                try {
                    " + code + @"
                    return ""Code executed successfully."";
                } catch (Exception ex) {
                    return ""Error: "" + ex.Message;
                }
            }
        }";

                CompilerResults results = codeProvider.CompileAssemblyFromSource(parameters, fullCode);

                if (results.Errors.HasErrors)
                {
                    StringBuilder errorMessages = new StringBuilder("Compilation Errors:\n");
                    foreach (CompilerError error in results.Errors)
                    {
                        errorMessages.AppendLine(error.ErrorText);
                    }
                    return errorMessages.ToString();
                }

                Assembly assembly = results.CompiledAssembly;
                Type userType = assembly.GetType("UserCode");
                MethodInfo method = userType.GetMethod("Main");

                return method.Invoke(null, null)?.ToString();
            }
        }

        private void RunButtton_Click(object sender, EventArgs e)
        {
            // Get the current selected tab and its TextBox
            TabPage selectedTab = tabControl.SelectedTab;
            if (tabTextBoxes.ContainsKey(selectedTab))
            {
                string userCode = tabTextBoxes[selectedTab].Text;
                string output = ExecuteCSharpCode(userCode);
                richTextBox1.Text = output;
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            // 1️⃣ Use Custom InputBox for project name input
            using (InputBox inputBox = new InputBox("Enter project name:"))
            {
                if (inputBox.ShowDialog() == DialogResult.OK)
                {
                    string projectName = inputBox.UserInput;

                    if (string.IsNullOrWhiteSpace(projectName))
                    {
                        MessageBox.Show("Project name cannot be empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // 2️⃣ Create directory with entered name
                    string basePath = @"C:\Users\david\Downloads\TJEngine - master\TJEngine - master";
                    string projectPath = Path.Combine(basePath, projectName);

                    Directory.CreateDirectory(projectPath);
                    Directory.CreateDirectory(Path.Combine(projectPath, "bin"));
                    Directory.CreateDirectory(Path.Combine(projectPath, "obj"));

                    // 3️⃣ Save code from the selected tab's TextBox
                    TabPage selectedTab = tabControl.SelectedTab;
                    if (tabTextBoxes.ContainsKey(selectedTab))
                    {
                        string csFilePath = Path.Combine(projectPath, "Program.cs");
                        File.WriteAllText(csFilePath, GenerateProgramFile(tabTextBoxes[selectedTab].Text));
                    }

                    // 4️⃣ Create .csproj file
                    string csprojPath = Path.Combine(projectPath, $"{projectName}.csproj");
                    File.WriteAllText(csprojPath, GenerateCsprojFile());

                    MessageBox.Show($"Project '{projectName}' saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private string GenerateProgramFile(string userCode)
        {
            return
$@"using System;

class Program
{{
    static void Main()
    {{
        {userCode}
    }}
}}";
        }

        private string GenerateCsprojFile()
        {
            return
@"<Project Sdk=""Microsoft.NET.Sdk"">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net6.0</TargetFramework>
  </PropertyGroup>
</Project>";
        }

        // InputBox Class: This should be placed outside the Form1 class
        public class InputBox : Form
        {
            private TextBox inputTextBox;
            private Button okButton;
            private Button cancelButton;
            private Label promptLabel;

            public string UserInput { get; private set; }

            public InputBox(string prompt)
            {
                this.Text = "Input";
                this.Size = new Size(300, 150);

                promptLabel = new Label
                {
                    Text = prompt,
                    Location = new Point(10, 20),
                    AutoSize = true
                };

                inputTextBox = new TextBox
                {
                    Location = new Point(10, 50),
                    Width = 260
                };

                okButton = new Button
                {
                    Text = "OK",
                    Location = new Point(100, 80),
                    DialogResult = DialogResult.OK
                };
                okButton.Click += (sender, e) =>
                {
                    UserInput = inputTextBox.Text;
                    this.Close();
                };

                cancelButton = new Button
                {
                    Text = "Cancel",
                    Location = new Point(180, 80),
                    DialogResult = DialogResult.Cancel
                };
                cancelButton.Click += (sender, e) => this.Close();

                Controls.Add(promptLabel);
                Controls.Add(inputTextBox);
                Controls.Add(okButton);
                Controls.Add(cancelButton);
            }
        }

        private void RefreshTabContent(TabPage selectedTab)
        {

            if (tabTextBoxes.ContainsKey(selectedTab))
            {
                TextBox selectedTextBox = tabTextBoxes[selectedTab];
                selectedTextBox.Focus(); // Ensure the TextBox for the selected tab is focused
            }
        }
    }
}
